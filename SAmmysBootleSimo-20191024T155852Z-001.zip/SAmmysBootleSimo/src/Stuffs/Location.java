package Stuffs;
import java.util.*;
import static Stuffs.Main.DisplayPane;

public class Location 
{
    public static void main(String[] args) 
    {
        
    }
    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    } 
    String position = "intro";
    public void town1(){
        position = "town1";
        DisplayPane.setText("Sam was a great and noble fighter but in these sad times, there are no monsters left to fight because he has removed the evil that infected this world.\n\nSam has been searching for any remaining monsters for a long time but in his heart he knows he will never find anymore.\n\nSam has wanderded into a small town.");
        Main.button1.setText("Look in a house");
        Main.button2.setText("Talk to trader");
        Main.button3.setText("Find food");
        Main.button4.setText("Stay in the inn");
    }
    public void house1(){
        position = "house1";
        DisplayPane.setText("Sam walks into a house full of ramen noodles and red soda cups.\n\nSam suspects a party that he missed.");
        Main.button1.setText("");
        Main.button2.setText("");
        Main.button3.setText("");
        Main.button4.setText("");
    }
}
